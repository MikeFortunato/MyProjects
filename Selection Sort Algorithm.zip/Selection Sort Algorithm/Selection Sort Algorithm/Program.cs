﻿using System;

namespace Selection_Sort_Algorithm
{
    class Program
    {
        static void Main(string[] args)
        {
            // Program: Selection Sort Algorithm  //
            // Written by: Michael Fortunato   //

            //Instantiate array
            int[] exampleArray = new int[] { 4, 15, 7, 20, 3, 8 };

            //Pass array to bubbleSort Method
            selectionSort(exampleArray);

            //bubbleSort Method
            void selectionSort(int[] array)
            {

                int n = array.Length;

                //temporary variable for element swap
                int temp;

                //Iterate through each element in the array
                for (int i = 0; i < n - 1; i++)
                {
                    //Stores min value
                    int min_index = i;

                    //Find min in sorted array
                    for (int j = i + 1; j <= n - 1; j++)
                    {
                        //swap if current element is greater than the next element
                        if (array[min_index] > array[j])
                        {
                            min_index = j;
                        }
                    }
                    //Swap elements
                    temp = array[min_index];
                    array[min_index] = array[i];
                    array[i] = temp;
                }

                //print/verify solution
                foreach (int p in array)
                {
                    Console.Write(p + " ");
                }
            }
        }
    }
}

﻿using System;

namespace Beginner_Functions
{
    class Program
    {
        static void Main(string[] args)
        {
            //===========Short and simple print to console programs===========//

            //Written by: Michael Fortunato

            //uncomment individually to run:

            //numbersEndIn7();
            //letters_A_Through_Z();
            //sum_of_Numbers();
            //largestNumber();
            //left_and_right_Sum();
            //even_and_odd_Sum();
            //sum_of_Vowels();

            void numbersEndIn7()
            {
                //prints numbers 1-1000 only ending in "7"

                for (int i = 1; i <= 1000; i++)
                {
                    if (i % 10 == 7)
                    {
                        Console.WriteLine(i);
                    }
                }
            }

            void letters_A_Through_Z()
            {
                //prints letters a - z

                for (char letter = 'a'; letter <= 'z'; letter++)
                {
                    Console.Write(letter + " ");
                }
            }

            void sum_of_Numbers()
            {
                //inputs n numbers and finds the sum

                int sum = 0;

                Console.Write("Enter amount of numbers to sum: ");
                int n = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine(); //blank line

                for (int i = 0; i < n; i++)
                {
                    Console.Write("Enter Number: ");
                    int number = Convert.ToInt32(Console.ReadLine());
                    sum += number;
                }

                Console.WriteLine("\nThe sum of your numbers is: " + sum + ".");

            }

            void largestNumber()
            {
                //inputs n numbers and find the largest number

                int largestNum = 0;

                Console.Write("Enter amount of numbers to check: ");
                int n = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine(); //blank line

                for (int i = 0; i < n; i++)
                {
                    Console.Write("Enter Number: ");
                    int number = Convert.ToInt32(Console.ReadLine());

                    if (number > largestNum)
                    {
                        largestNum = number;
                    }
                }

                Console.WriteLine("\nThe largest numbers is: " + largestNum + ".");
            }

            void left_and_right_Sum()
            {
                //inputs 2 sets of n numbers 
                //if they are equal prints the sum (individual set sum) , if not prints the difference (both sums)

                int firstSum = 0;
                int secondSum = 0;
                int difference = 0;

                Console.Write("Enter amount of numbers to check: ");
                int n = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("_________________\n\nFirst Set");

                for (int i = 0; i < n; i++)
                {

                    Console.Write("\nEnter Number: ");
                    int num = Convert.ToInt32(Console.ReadLine());
                    firstSum += num;
                }

                Console.WriteLine("_________________\n\nSecond Set");

                for (int i = 0; i < n; i++)
                {
                    Console.Write("\nEnter Number: ");
                    int num = Convert.ToInt32(Console.ReadLine());
                    secondSum += num;
                }

                Console.WriteLine("________________\n\nResults");

                if (firstSum == secondSum)
                {
                    Console.Write("\nYes, the sum is: " + firstSum + ".\n");
                }
                else
                {
                    difference = firstSum - secondSum;
                    Console.Write("\nNo, the difference is: " + Math.Abs(difference) + ".\n");
                }
            }

            void even_and_odd_Sum()
            {
                //inputs n numbers
                //checks by even/odd positions
                //if they are equal prints the sum, if not prints the difference

                int evenSum = 0;
                int oddSum = 0;
                int difference = 0;

                Console.Write("Enter amount of numbers to check: ");
                int n = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("_________________\n\nNumbers:");

                for (int i = 1; i <= n; i++)
                {

                    Console.Write("\nEnter Number: ");
                    int num = Convert.ToInt32(Console.ReadLine());

                    if (i % 2 == 0)
                    {
                        evenSum += num;
                    }
                    else
                    {
                        oddSum += num;
                    }
                }

                Console.WriteLine("________________\n\nResults");

                if (evenSum == oddSum)
                {
                    Console.Write("\nYes, the sum is: " + evenSum + ".\n");
                }
                else
                {
                    difference = evenSum - oddSum;
                    Console.Write("\nNo, the difference is: " + Math.Abs(difference) + ".\n");
                }
            }

            void sum_of_Vowels()
            {
                //gives vowels a value and inputs a string to sum the values

                Console.WriteLine("a = 1 | e = 2 | i = 3 | o = 4 | u = 5\n");
                Console.Write("Enter a word to sum the vowels: ");
                string word = Console.ReadLine();
                int sum = 0;

                for (int i = 0; i < word.Length; i++)
                {
                    if (word[i] == 'a')
                    {
                        sum += 1;
                    }
                    else if (word[i] == 'e')
                    {
                        sum += 2;
                    }
                    else if (word[i] == 'i')
                    {
                        sum += 3;
                    }
                    else if (word[i] == 'o')
                    {
                        sum += 4;
                    }
                    else if (word[i] == 'u')
                    {
                        sum += 5;
                    }
                }

                Console.WriteLine("The sum of the vowels is {0}.", sum);

            }

            //Leetcode problem 1:

            int[] TwoSum(int[] nums, int target)
            {
                for (int i = 0; i < nums.Length; i++)
                {
                    for (int j = i + 1; j < nums.Length; j++)
                    {
                        if (nums[i] + nums[j] == target)
                        {
                            nums = new int[] { i, j };
                        }
                    }
                }
                return nums;
            }
        }
    }
}

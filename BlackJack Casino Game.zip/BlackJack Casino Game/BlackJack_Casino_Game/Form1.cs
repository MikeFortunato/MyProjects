﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace BlackJack_Casino_Game
{
    /*
        Program: BlackJack Casino Game
        Written by: Michael Fortunato
        
        Important Info:

        -Labeling of form items and organization not prioritized.
        -This was a project made to develop self knowledge.
        -The "Deal Me Aces" button was used for testing purposes only: Ace value's swap from  1 to 11 or 11 to 1.
        -Click on an Ace to change its value.
    */

    public partial class Form1 : Form
    {
        //objects
        Cards DeckofCards = new Cards();
        Hand PlayerHand = new Hand("Player");
        Hand DealerHand = new Hand("Dealer");
        Funds myFunds = new Funds(500);

        //booleans
        bool endHand = false;
        bool isFirstHand = true;
        bool didPlayerBust = false;

        public Form1()
        {
            InitializeComponent();
            this.Size = new Size(1200, 850);
            button1.AutoSize = true;
            ShowTotalValues();
            label17.Text = "Funds $" + myFunds.GetTotalMoney();

            //bet increments
            numericUpDown1.Minimum = 10;
            numericUpDown1.Increment = 10;
        }

        //---------------------------//
        //    BUTTON CLICK EVENTS    //
        //---------------------------//

        private void Button1_Click(object sender, EventArgs e) //fsw button
        {
            BigPurpleBucsButton();
        }

        private void Button4_Click(object sender, EventArgs e) //hit me button
        {
            HitMeButton();
        }

        private void Button5_Click(object sender, EventArgs e) //stay button
        {
            StayButton();
        }

        //---------------------------//
        //       END THE HAND        //
        //---------------------------//

        private void EndHand()
        {
            endHand = true;

            //reset hand objects
            PlayerHand.ResetHand();
            DealerHand.ResetHand();

            //reset bool
            didPlayerBust = false;

            //card 
            Card ACard = DeckofCards.GetNextCard();

            //player card buttons
            PlayerHand.DealACardToMe(ACard);
            button6.Image = ACard.BackCardImage();
            button7.Image = ACard.BackCardImage();
            button8.Image = ACard.BackCardImage();
            button9.Image = ACard.BackCardImage();
            button10.Image = ACard.BackCardImage();

            //player card value = "?"
            label8.Text = "?";
            label9.Text = "?";
            label10.Text = "?";
            label11.Text = "?";
            label12.Text = "?";

            //dealer card buttons
            DealerHand.DealACardToMe(ACard);
            button2.Image = ACard.BackCardImage();
            button3.Image = ACard.BackCardImage();
            button11.Image = ACard.BackCardImage();
            button12.Image = ACard.BackCardImage();
            button13.Image = ACard.BackCardImage();

            //dealer card value = "?"
            label1.Text = "?";
            label2.Text = "?";
            label3.Text = "?";
            label4.Text = "?";
            label7.Text = "?";

            label15.Text = ("Total Value of Players Hand is: ?");
            label16.Text = ("Total Value of Players Hand is: ?");
        }

        //---------------------------//
        //       RESET THE HAND      //
        //---------------------------//

        private void ResetHand()

        {
            //reset hand objects
            PlayerHand.ResetHand();
            DealerHand.ResetHand();

            //reset bool
            didPlayerBust = false;

            //Dealer Card 1
            Card ACard = DeckofCards.GetNextCard();
            DealerHand.DealACardToMe(ACard);
            button2.Image = ACard.GetCardImage();
            label2.Text = "" + ACard.GetCardValue();
            label15.Text = "Total Value of Dealers Hand is: " + DealerHand.GetCardValue(0);

            //Dealer Card 2
            ACard = DeckofCards.GetNextCard();
            DealerHand.DealACardToMe(ACard);
            button3.Image = ACard.BackCardImage();
            label1.Text = "?";

            //Dealer Card 3
            button11.Image = ACard.BackCardImage();
            label3.Text = "" + ACard.BackCardValue();

            //Dealer Card 4
            button12.Image = ACard.BackCardImage();
            label4.Text = "" + ACard.BackCardValue();

            //Dealer Card 5
            button13.Image = ACard.BackCardImage();
            label7.Text = "" + ACard.BackCardValue();

            //Player Card 1
            ACard = DeckofCards.GetNextCard();
            PlayerHand.DealACardToMe(ACard);
            button6.Image = ACard.GetCardImage();
            label8.Text = "" + ACard.GetCardValue();

            //Player Card 2
            ACard = DeckofCards.GetNextCard();
            PlayerHand.DealACardToMe(ACard);
            button7.Image = ACard.GetCardImage();
            label9.Text = "" + ACard.GetCardValue();
            label16.Text = ("Total Value of Players Hand is: " + PlayerHand.GetValueofCards().ToString());

            //Player Card 3
            button8.Image = ACard.BackCardImage();
            label10.Text = "" + ACard.BackCardValue();

            //Player Card 4
            button9.Image = ACard.BackCardImage();
            label11.Text = "" + ACard.BackCardValue();

            //Player Card 5
            button10.Image = ACard.BackCardImage();
            label12.Text = "" + ACard.BackCardValue();
        }

        //---------------------------//
        //       HIT ME BUTTON       //
        //---------------------------//

        private void HitMeButton()
        {
            //card object reference
            Card ACard = DeckofCards.GetNextCard();

            if (endHand == false)
            {
                //player hits / case number equals the number of cards in hand at the time of hit
                switch (PlayerHand.GetNumberofCards())
                {
                    //two cards out
                    case 2:
                        //reveal 3rd card
                        ACard = DeckofCards.GetNextCard();
                        PlayerHand.DealACardToMe(ACard);
                        button8.Image = ACard.GetCardImage();
                        label10.Text = "" + ACard.GetCardValue();
                        PlayerAcesLogic();
                        ShowPlayerTotals();
                        CheckIfPlayerBusts(PlayerHand.GetValueofCards());

                        if (didPlayerBust)
                        {
                            LostBet();
                            EndHand();
                        }

                        break;

                    //three cards out
                    case 3:
                        //reveal 4rd card
                        ACard = DeckofCards.GetNextCard();
                        PlayerHand.DealACardToMe(ACard);
                        button9.Image = ACard.GetCardImage();
                        label11.Text = "" + ACard.GetCardValue();
                        PlayerAcesLogic();
                        ShowPlayerTotals();
                        CheckIfPlayerBusts(PlayerHand.GetValueofCards());

                        if (didPlayerBust)
                        {
                            LostBet();
                            EndHand();
                        }

                        break;

                    //four cards out
                    case 4:
                        //reveal 5rd card
                        ACard = DeckofCards.GetNextCard();
                        PlayerHand.DealACardToMe(ACard);
                        button10.Image = ACard.GetCardImage();
                        label12.Text = "" + ACard.GetCardValue();
                        PlayerAcesLogic();
                        ShowPlayerTotals();
                        StayButton();
                        break;
                }
            }
        }

        //---------------------------//
        //        STAY BUTTON        //
        //---------------------------//

        private void StayButton()
        {
            //card object reference
            Card ACard = DeckofCards.GetNextCard();

            if (endHand == false)
            {
                //reveal dealers second card here:
                ACard = DeckofCards.GetNextCard();
                button3.Image = DealerHand.GetCardImage(1);
                label1.Text = "" + DealerHand.GetCardValue(1);
                //DealerAcesLogic();
                ShowTotalValues();

                if (DealerHand.GetValueofCards() < 17)
                {
                    //give dealer a third card
                    ACard = DeckofCards.GetNextCard();
                    DealerHand.DealACardToMe(ACard);
                    button11.Image = DealerHand.GetCardImage(2);
                    label3.Text = "" + DealerHand.GetCardValue(2);
                    DealerAcesLogic();
                    ShowTotalValues();

                    //give dealer a fouth card
                    if (DealerHand.GetValueofCards() < 17)
                    {
                        ACard = DeckofCards.GetNextCard();
                        DealerHand.DealACardToMe(ACard);
                        button12.Image = DealerHand.GetCardImage(3);
                        label4.Text = "" + DealerHand.GetCardValue(3);
                        DealerAcesLogic();
                        ShowTotalValues();

                        //give dealer a fifth card 
                        if (DealerHand.GetValueofCards() < 17)
                        {
                            ACard = DeckofCards.GetNextCard();
                            DealerHand.DealACardToMe(ACard);
                            button13.Image = DealerHand.GetCardImage(4);
                            label7.Text = "" + DealerHand.GetCardValue(4);

                            DealerAcesLogic();
                            ShowTotalValues();
                            ShowMessage();
                            EndHand();
                        }

                        else
                        {
                            DealerAcesLogic();
                            ShowTotalValues();
                            ShowMessage();
                            EndHand();
                        }
                    }

                    else
                    {
                        //show dealers third card 
                        button11.Image = ACard.GetCardImage();
                        label3.Text = "" + ACard.GetCardValue();
                        DealerAcesLogic();
                        ShowTotalValues();
                        ShowMessage();
                        EndHand();
                    }
                }

                else
                {
                    DealerAcesLogic();
                    ShowTotalValues();
                    ShowMessage();
                    EndHand();
                }
            }
        }

        //-------------------------------------//
        //    CALCULATES & DISPLAYS RESULTS    //
        //-------------------------------------//

        private void ShowMessage()
        {
            //dealer and player tie / both hands 21 or less
            if (DealerHand.GetValueofCards() == PlayerHand.GetValueofCards() && DealerHand.GetValueofCards() <= 21 && PlayerHand.GetValueofCards() <= 21)
            {
                MessageBox.Show("Dealers hand value: " + DealerHand.GetValueofCards().ToString() + "\n" +
                    "Your hand value: " + PlayerHand.GetValueofCards().ToString(), "IT'S A DRAW!!");
            }

            //dealer aand player tie / both hands over 21
            else if (DealerHand.GetValueofCards() == PlayerHand.GetValueofCards() && DealerHand.GetValueofCards() > 21 && PlayerHand.GetValueofCards() > 21)
            {
                LostBet();
                MessageBox.Show("Dealers hand value: " + DealerHand.GetValueofCards().ToString() + "\n" +
                   "Your hand value: " + PlayerHand.GetValueofCards().ToString(), "YOU LOSE!!");
            }

            //dealers hand wins as long as its less than or equal to 21
            else if (DealerHand.GetValueofCards() > PlayerHand.GetValueofCards() && DealerHand.GetValueofCards() <= 21)
            {
                LostBet();
                MessageBox.Show("Dealers hand value: " + DealerHand.GetValueofCards().ToString() + "\n" +
                    "Your hand value: " + PlayerHand.GetValueofCards().ToString(), "YOU LOSE!!");
            }

            //players hand wins as long as its less than or equal to 21
            else if (DealerHand.GetValueofCards() < PlayerHand.GetValueofCards() && PlayerHand.GetValueofCards() <= 21)
            {
                WonBet();
                MessageBox.Show("Dealers hand value: " + DealerHand.GetValueofCards().ToString() + "\n" +
                    "Your hand value: " + PlayerHand.GetValueofCards().ToString(), "YOU WIN!!");
            }

            //dealers hand over 21 players hand under 22
            else if (DealerHand.GetValueofCards() > PlayerHand.GetValueofCards() && DealerHand.GetValueofCards() > 21 && PlayerHand.GetValueofCards() <= 21)
            {
                WonBet();
                MessageBox.Show("Dealers hand value: " + DealerHand.GetValueofCards().ToString() + "\n" +
                   "Your hand value: " + PlayerHand.GetValueofCards().ToString(), "YOU WIN!!");
            }
            //player hand over 21 
            else if (DealerHand.GetValueofCards() < PlayerHand.GetValueofCards() && PlayerHand.GetValueofCards() > 21)
            {
                LostBet();
                MessageBox.Show("Dealers hand value: " + DealerHand.GetValueofCards().ToString() + "\n" +
                   "Your hand value: " + PlayerHand.GetValueofCards().ToString(), "YOU LOSE!!");
            }
        }

        //---------------------------//
        //  CHECKS IF PLAYER BUSTS   //
        //---------------------------//

        private bool CheckIfPlayerBusts(int playerHandValue)
        {
            //checks if players hand exceeds 21
            if (playerHandValue > 21)
            {
                didPlayerBust = true;
                MessageBox.Show("Your hand exceeds 21\n" + "Your hand value: " + PlayerHand.GetValueofCards().ToString(), "You LOSE!");
            }

            return didPlayerBust;
        }

        //---------------------------//
        //   CHECKS FOR BLACKJACK    //
        //---------------------------//

        private bool CheckForBlackJack(int playerHandValue)
        {
            bool didPlayerBlackJack = false;

            if (playerHandValue == 21)
            {
                didPlayerBlackJack = true;
                MessageBox.Show("Your hand value is 21!", "BlackJack!!!");
                StayButton();
            }

            return didPlayerBlackJack;
        }

        //---------------------------//
        //    DISPLAY HAND TOTALS    //
        //---------------------------//

        private void ShowTotalValues()
        {
            if (didPlayerBust)
            {
                label15.Text = ("");
                label16.Text = ("Total Value of Players Hand is: " + PlayerHand.GetValueofCards().ToString());
            }

            else
            {
                //Displays hand totals for player and dealer
                label15.Text = ("Total Value of Dealers Hand is: " + DealerHand.GetValueofCards().ToString());
                label16.Text = ("Total Value of Players Hand is: " + PlayerHand.GetValueofCards().ToString());
            }
        }

        private void ShowPlayerTotals()
        {
            label16.Text = ("Total Value of Your Hand is: " + PlayerHand.GetValueofCards().ToString());
        }

        private void ShowDealerTotals()
        {
            label15.Text = ("Total Value of Dealers Hand is: " + DealerHand.GetValueofCards().ToString());
        }

        //---------------------------//
        //    DEAL ME ACES BUTTON    //
        //---------------------------//

        private void Button14_Click(object sender, EventArgs e)
        {
            //deal aces button
            DeckofCards.LoadCards();
            DeckofCards.PutAcesFirst();
            BigPurpleBucsButton();
            DeckofCards.shuffleCards();
        }

        //---------------------------//
        //         FSW BUTTON        //
        //---------------------------//

        private void BigPurpleBucsButton()
        {
            if (isFirstHand)
            {
                //initializes new hand
                ResetHand();

                //check for blackjack upon deal
                CheckForBlackJack(PlayerHand.GetValueofCards());

                isFirstHand = false;
            }

            if (endHand)
            {
                endHand = false;

                //initializes new hand
                ResetHand();

                //check for blackjack upon deal
                CheckForBlackJack(PlayerHand.GetValueofCards());
            }
        }

        //---------------------------//
        //    PLAYERCARD 1 BUTTON    //
        //---------------------------//

        private void Button6_Click(object sender, EventArgs e)
        {

            if (PlayerHand.GetIsanAce(0) && PlayerHand.GetCardValue(0) == 11)
            {
                DialogResult dialogResult = MessageBox.Show("Do you want to change the Ace value to 1?", "Black Jack", MessageBoxButtons.YesNo);
                if (dialogResult == DialogResult.Yes)
                {
                    PlayerHand.SetAceValueTo1(0);
                    label8.Text = "" + PlayerHand.GetCardValue(0).ToString();
                    label16.Text = ("Total Value of Players Hand is: " + PlayerHand.GetValueofCards().ToString());
                }
                else if (dialogResult == DialogResult.No)
                {

                }
            }

            else if (PlayerHand.GetIsanAce(0) && PlayerHand.GetCardValue(0) == 1)
            {
                DialogResult dialogResult = MessageBox.Show("Do you want to change the Ace value to 11?", "Black Jack", MessageBoxButtons.YesNo);
                if (dialogResult == DialogResult.Yes)
                {
                    PlayerHand.SetAceValueTo11(0);
                    label8.Text = "" + PlayerHand.GetCardValue(0).ToString();
                    label16.Text = ("Total Value of Players Hand is: " + PlayerHand.GetValueofCards().ToString());
                }
                else if (dialogResult == DialogResult.No)
                {

                }
            }
        }

        //---------------------------//
        //    PLAYERCARD 2 BUTTON    //
        //---------------------------//

        private void Button7_Click(object sender, EventArgs e)
        {

            if (PlayerHand.GetIsanAce(1) && PlayerHand.GetCardValue(1) == 11)
            {

                DialogResult dialogResult = MessageBox.Show("Do you want to change the Ace value to 1?", "Black Jack", MessageBoxButtons.YesNo);
                if (dialogResult == DialogResult.Yes)
                {
                    PlayerHand.SetAceValueTo1(1);
                    label9.Text = "" + PlayerHand.GetCardValue(1).ToString();
                    label16.Text = ("Total Value of Players Hand is: " + PlayerHand.GetValueofCards().ToString());
                }
                else if (dialogResult == DialogResult.No)
                {

                }
            }

            else if (PlayerHand.GetIsanAce(1) && PlayerHand.GetCardValue(1) == 1)
            {
                DialogResult dialogResult = MessageBox.Show("Do you want to change the Ace value to 11?", "Black Jack", MessageBoxButtons.YesNo);
                if (dialogResult == DialogResult.Yes)
                {
                    PlayerHand.SetAceValueTo11(1);
                    label9.Text = "" + PlayerHand.GetCardValue(1).ToString();
                    label16.Text = ("Total Value of Players Hand is: " + PlayerHand.GetValueofCards().ToString());
                }
                else if (dialogResult == DialogResult.No)
                {

                }
            }
        }

        //---------------------------//
        //    PLAYERCARD 3 BUTTON    //
        //---------------------------//

        private void Button8_Click(object sender, EventArgs e)
        {
            //players third card button
            if (PlayerHand.GetIsanAce(2) && PlayerHand.GetCardValue(2) == 11)
            {

                DialogResult dialogResult = MessageBox.Show("Do you want to change the Ace value to 1?", "Black Jack", MessageBoxButtons.YesNo);
                if (dialogResult == DialogResult.Yes)
                {
                    PlayerHand.SetAceValueTo1(2);
                    label10.Text = "" + PlayerHand.GetCardValue(2).ToString();
                    label16.Text = ("Total Value of Players Hand is: " + PlayerHand.GetValueofCards().ToString());
                }
                else if (dialogResult == DialogResult.No)
                {

                }
            }

            else if (PlayerHand.GetIsanAce(2) && PlayerHand.GetCardValue(2) == 1)
            {
                DialogResult dialogResult = MessageBox.Show("Do you want to change the Ace value to 11?", "Black Jack", MessageBoxButtons.YesNo);
                if (dialogResult == DialogResult.Yes)
                {
                    PlayerHand.SetAceValueTo11(2);
                    label10.Text = "" + PlayerHand.GetCardValue(2).ToString();
                    label16.Text = ("Total Value of Players Hand is: " + PlayerHand.GetValueofCards().ToString());
                }
                else if (dialogResult == DialogResult.No)
                {

                }
            }
        }

        //---------------------------//
        //    PLAYERCARD 4 BUTTON    //
        //---------------------------//

        private void Button9_Click(object sender, EventArgs e)
        {
            //player card 4 button
            if (PlayerHand.GetIsanAce(3) && PlayerHand.GetCardValue(3) == 11)
            {

                DialogResult dialogResult = MessageBox.Show("Do you want to change the Ace value to 1?", "Black Jack", MessageBoxButtons.YesNo);
                if (dialogResult == DialogResult.Yes)
                {
                    PlayerHand.SetAceValueTo1(3);
                    label11.Text = "" + PlayerHand.GetCardValue(3).ToString();
                    label16.Text = ("Total Value of Players Hand is: " + PlayerHand.GetValueofCards().ToString());
                }
                else if (dialogResult == DialogResult.No)
                {

                }
            }

            else if (PlayerHand.GetIsanAce(3) && PlayerHand.GetCardValue(3) == 1)
            {
                DialogResult dialogResult = MessageBox.Show("Do you want to change the Ace value to 11?", "Black Jack", MessageBoxButtons.YesNo);
                if (dialogResult == DialogResult.Yes)
                {
                    PlayerHand.SetAceValueTo11(3);
                    label11.Text = "" + PlayerHand.GetCardValue(3).ToString();
                    label16.Text = ("Total Value of Players Hand is: " + PlayerHand.GetValueofCards().ToString());
                }
                else if (dialogResult == DialogResult.No)
                {

                }
            }
        }

        //---------------------------//
        //    PLAYERCARD 5 BUTTON    //
        //---------------------------//

        private void Button10_Click(object sender, EventArgs e)
        {
            //player card 5 button
            if (PlayerHand.GetIsanAce(4) && PlayerHand.GetCardValue(4) == 11)
            {

                DialogResult dialogResult = MessageBox.Show("Do you want to change the Ace value to 1?", "Black Jack", MessageBoxButtons.YesNo);
                if (dialogResult == DialogResult.Yes)
                {
                    PlayerHand.SetAceValueTo1(4);
                    label12.Text = "" + PlayerHand.GetCardValue(4).ToString();
                    label16.Text = ("Total Value of Players Hand is: " + PlayerHand.GetValueofCards().ToString());
                }
                else if (dialogResult == DialogResult.No)
                {

                }
            }

            else if (PlayerHand.GetIsanAce(4) && PlayerHand.GetCardValue(4) == 1)
            {
                DialogResult dialogResult = MessageBox.Show("Do you want to change the Ace value to 11?", "Black Jack", MessageBoxButtons.YesNo);
                if (dialogResult == DialogResult.Yes)
                {
                    PlayerHand.SetAceValueTo11(4);
                    label12.Text = "" + PlayerHand.GetCardValue(4).ToString();
                    label16.Text = ("Total Value of Players Hand is: " + PlayerHand.GetValueofCards().ToString());
                }
                else if (dialogResult == DialogResult.No)
                {

                }
            }
        }

        //-----------------------------//
        //    DEALER HAND ACES LOGIC   //
        //-----------------------------//

        private void DealerAcesLogic()
        {
            if (DealerHand.GetValueofCards() > 21)
            {
                for (int index = 0; index < DealerHand.GetNumberofCards(); index++)
                {
                    if (DealerHand.GetIsanAce(index))
                    {
                        DealerHand.SetAceValueTo1(index);
                    }
                }
            }
        }

        //-----------------------------//
        //    PLAYER HAND ACES LOGIC   //
        //-----------------------------//

        private void PlayerAcesLogic()
        {
            if (PlayerHand.GetValueofCards() > 21)
            {
                for (int index = 0; index < PlayerHand.GetNumberofCards(); index++)
                {
                    if (PlayerHand.GetIsanAce(index))
                    {
                        PlayerHand.SetAceValueTo1(index);

                        switch (index)
                        {
                            case 0:
                                label8.Text = PlayerHand.GetCardValue(index).ToString();
                                break;
                            case 1:
                                label9.Text = PlayerHand.GetCardValue(index).ToString();
                                break;
                            case 2:
                                label10.Text = PlayerHand.GetCardValue(index).ToString();
                                break;
                            case 3:
                                label11.Text = PlayerHand.GetCardValue(index).ToString();
                                break;
                            case 4:
                                label12.Text = PlayerHand.GetCardValue(index).ToString();
                                break;

                        }

                        ShowPlayerTotals();
                    }
                }
            }
        }

        //-----------------------------//
        //     Win Bet Calcuclation    //
        //-----------------------------//

        public void WonBet()
        {
            myFunds.WonBet();
            label17.Text = "Funds $" + myFunds.GetTotalMoney();
        }

        //-----------------------------//
        //     Lost Bet Calcuclation   //
        //-----------------------------//

        public void LostBet()
        {
            myFunds.LostBet();
            label17.Text = "Funds $" + myFunds.GetTotalMoney();
        }

        //-----------------------------//
        //        SET BET AMOUNT       //
        //-----------------------------//

        private void NumericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            myFunds.SetBetAmount((int)numericUpDown1.Value);
        }
    }
}


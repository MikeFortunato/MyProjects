﻿using System.Drawing;

namespace BlackJack_Casino_Game
{

    //This is a hand class (5 of 52 cards per hand)
    class Hand
    {
        string NameofPlayer;
        Card[] MyCards = new Card[5];
        int totalvalue = 0;
        int numberofcards = 0;
        int cardvalue = 0;
        Image CardImage;

        public Hand(string name)
        {
            NameofPlayer = name;
        }

        public void DealACardToMe(Card ACard)
        {
            if (numberofcards < 5)
            {
                MyCards[numberofcards] = ACard;
                totalvalue = totalvalue + ACard.GetCardValue();
                numberofcards++;
            }
        }

        public void SetAceValueTo1(int index)
        {
            MyCards[index].ChangeAceValueTo1();
            totalvalue = GetValueofCards();
        }

        public void SetAceValueTo11(int index)
        {
            MyCards[index].ChangeAceValueTo11();
            totalvalue = GetValueofCards();
        }

        public int GetNumberofCards()
        {
            return numberofcards;
        }

        public int GetValueofCards()
        {
            totalvalue = 0;
            for (int i = 0; i < numberofcards; i++)
            {
                totalvalue = totalvalue + MyCards[i].GetCardValue();
            }
            return totalvalue;
        }

        public int GetCardValue(int index)
        {
            cardvalue = MyCards[index].GetCardValue();
            return cardvalue;
        }

        public Image GetCardImage(int index)
        {
            CardImage = MyCards[index].GetCardImage();
            return CardImage;
        }

        public void ResetHand()
        {
            totalvalue = 0;
            numberofcards = 0;
        }

        public bool GetIsanAce(int index)
        {
            bool isAce = false;

            if (MyCards[index] != null && MyCards[index].GetCardisanAce())
            {
                isAce = true;
            }
            return isAce;
        }
    }
}

﻿
namespace BlackJack_Casino_Game
{

    //This is the funds class used for placing bets
    class Funds
    {
        private int totalMoney = 0;
        private int betAmount = 10;

        public Funds(int initialfunds)
        {
            totalMoney = initialfunds;
        }

        public int GetTotalMoney()
        {
            return totalMoney;
        }

        public int GetBetAmount()
        {
            return betAmount;
        }

        public void SetBetAmount(int betamt)
        {
            betAmount = betamt;
        }

        public void WonBet()
        {
            totalMoney = totalMoney + betAmount;
        }

        public void LostBet()
        {
            totalMoney = totalMoney - betAmount;
        }
    }
}

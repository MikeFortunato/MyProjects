﻿using System;
using System.IO;
using System.Drawing;
using System.Windows.Forms;

namespace BlackJack_Casino_Game
{

    //This is the deck class (All 52 cards)
    class Cards
    {
        private Card[] AllCards = new Card[52];
        private int currentcard = 0;

        public Cards()
        {
            LoadCards();
            shuffleCards();
        }

        public void LoadCards()
        {
            Card ACard;
            String msg = "";
            int tries = 0;
            try
            {
                string[] list = Directory.GetFiles(@"cards", "*.gif");
                Array.Sort(list);

                for (int index = 0; index < 52; index++)
                {
                    int value = GetNextCardValue(index);
                    Image image = Image.FromFile(list[index]);

                    ACard = new Card(image, value);
                    if (index > 31 && index < 36)
                    {
                        ACard.SetCardToAce();
                    }
                    AllCards[index] = ACard;
                }
            }
            catch (Exception e)
            {
                if (tries < 2)
                {
                    msg = "Error Please make sure the card files in the Directory. \nWhen you put the cards in the Directory hit OK button.\n\n " + e.ToString();
                    MessageBox.Show(msg);
                    tries++;
                    LoadCards();

                }
                else
                {
                    Environment.Exit(1);
                }
            }
        }

        public void PutAcesFirst()
        {
            int aceindex = 0;
            for (int index = 0; index < 52; index++)
            {
                Card TempCard1 = AllCards[index];

                if (TempCard1.GetCardisanAce())
                {
                    Card OriginalCard = AllCards[aceindex];
                    TempCard1.ChangeAceValueTo11();
                    AllCards[aceindex] = TempCard1;
                    AllCards[index] = OriginalCard;
                    aceindex++;
                }

            }

            for (int index = 0; index < 52; index++)
            {
                Card TempCard1 = AllCards[index];
                if (TempCard1.GetCardValue() == 10)
                {
                    Card TempCardJack = AllCards[index];
                    Card TempCard4 = AllCards[4];
                    AllCards[index] = TempCard4;
                    AllCards[4] = TempCardJack;
                }
            }
            currentcard = 0;//RWW
        }

        public Card GetNextCard()
        {
            int value = currentcard;
            currentcard++;

            if (currentcard >= 52)
            {
                currentcard = 0;
                shuffleCards();
            }

            return AllCards[value];
        }

        public int GetCurrentCardNumber()
        {
            return currentcard;
        }

        public int GetNextCardValue(int currentcard)
        {
            int cardvalue = 0;
            if (currentcard < 32)
            {
                cardvalue = (currentcard / 4) + 2;
            }

            else if (currentcard >= 32 && currentcard <= 35)
            {
                cardvalue = 11;
            }

            else
            {
                cardvalue = 10;
            }

            return cardvalue;
        }

        public void shuffleCards()
        {
            Random random = new Random();
            int numTimes = random.Next(41, 100);

            for (int x = 0; x < numTimes; x++)
            {
                int r1 = random.Next(51);
                int r2 = random.Next(51);
                Card C1 = AllCards[r1];
                Card C2 = AllCards[r2];
                AllCards[r2] = C1;
                AllCards[r1] = C2;
            }

        }
    }
}

﻿using System;
using System.Drawing;
using System.IO;

namespace BlackJack_Casino_Game
{

    //This is the card class (1 of 52 cards)
    class Card
    {
        private Image image;
        private int value;
        private Boolean IsAce;

        public Card()
        {

        }

        public Card(Image myimage, int myvalue)
        {
            image = myimage;
            value = myvalue;
            IsAce = false;
        }

        public Image BackCardImage()
        {
            string[] list = Directory.GetFiles(@"ButtonImages", "*.gif");
            Image image = Image.FromFile(list[0]);
            return image;
        }

        public string BackCardValue()
        {
            string value = "?";
            return value;
        }

        public Image GetCardImage()
        {
            return image;
        }

        public int GetCardValue()
        {
            return value;
        }

        public Image GetAceCard()
        {
            string[] list = Directory.GetFiles(@"cards", "*.gif");
            Image image = Image.FromFile(list[35]);
            return image;
        }

        public int GetAceValue()
        {
            int myValue = 11;
            return myValue;
        }

        public int ChangeAceValueTo1()
        {
            value = 1;
            return value;
        }

        public int ChangeAceValueTo11()
        {
            value = 11;
            return value;
        }

        public bool GetCardisanAce()
        {
            return IsAce;
        }

        public void SetCardToAce()
        {
            IsAce = true;
        }

    }
}

﻿using System;

namespace Bubble_Sort_Algorithm
{
    class Program
    {
        static void Main(string[] args)
        {
            // Program: Bubble Sort Algorithm  //
            // Written by: Michael Fortunato   //

            //Instantiate array
            int[] exampleArray = new int[] { 4, 15, 7, 20, 3, 8 };

            //Pass array to bubbleSort Method
            bubbleSort(exampleArray);

            //bubbleSort Method
            void bubbleSort(int[] array)
            {

                int n = array.Length;

                //temporary variable for element swap
                int temp;

                //Iterate through each element in the array
                for (int i = 0; i < n - 1; i++)
                {
                    //Iterate through each element minus elements already sorted
                    for (int j = 0; j < n - i - 1; j++)
                    {
                        //swap if current element is greater than the next element
                        if (array[j] > array[j + 1])
                        {
                            temp = array[j + 1];
                            array[j + 1] = array[j];
                            array[j] = temp;
                        }
                    }
                }

                //print/verify solution
                foreach (int p in array)
                {
                    Console.Write(p + " ");
                }
            }
        }
    }
}
